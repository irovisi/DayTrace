@echo off
chcp 65001 >nul
title DayTrace - autostart setup
:: ── DayTrace autostart installer ──
:: Creates a shortcut in the Windows Startup folder so DayTrace launches
:: automatically on login (hidden, no console window).

set "SCRIPT_DIR=%~dp0"
set "TARGET=%SCRIPT_DIR%tracker.py"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SHORTCUT=%STARTUP%\DayTrace.lnk"

:: 1. Find the real full path to pythonw.exe. A bare "pythonw.exe" target
::    fails at login if Python is not on the machine-wide PATH.
set "PYW="
for /f "delims=" %%i in ('where pythonw.exe 2^>nul') do (
    if not defined PYW set "PYW=%%i"
)

if not defined PYW (
    :: Fallback: derive from python.exe location
    for /f "delims=" %%i in ('where python.exe 2^>nul') do (
        if not defined PYW set "PYW=%%~dpipythonw.exe"
    )
)

if not defined PYW (
    echo.
    echo  Python was not found on PATH.
    echo  Install Python from https://python.org and during setup
    echo  check "Add Python to PATH", then run this file again.
    echo.
    pause
    exit /b 1
)

echo  Using interpreter: %PYW%
echo  Target script:     %TARGET%

:: 2. Build the shortcut with an absolute interpreter path via PowerShell
::    (more reliable than VBScript across locales).
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$lnk = $ws.CreateShortcut('%SHORTCUT%');" ^
  "$lnk.TargetPath = '%PYW%';" ^
  "$lnk.Arguments = '\"%TARGET%\"';" ^
  "$lnk.WorkingDirectory = '%SCRIPT_DIR%';" ^
  "$lnk.WindowStyle = 7;" ^
  "$lnk.Description = 'DayTrace Activity Tracker';" ^
  "$lnk.Save()"

if exist "%SHORTCUT%" (
    echo.
    echo  DayTrace added to startup successfully.
    echo  It will launch automatically on next login.
    echo.
    echo  Starting DayTrace now for this session...
    start "" "%PYW%" "%TARGET%"
    echo.
    echo  To remove autostart later: delete DayTrace.lnk from
    echo  %STARTUP%
) else (
    echo.
    echo  Failed to create the startup shortcut.
    echo  Check that you have write access to:
    echo  %STARTUP%
)
echo.
pause
