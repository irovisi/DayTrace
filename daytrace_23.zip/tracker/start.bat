@echo off
chcp 65001 >nul
title DayTrace

python --version >nul 2>&1
if errorlevel 1 (
    echo Python not found. Download from https://python.org
    echo During install, check "Add Python to PATH".
    pause
    exit /b 1
)

echo Installing dependencies...
pip install flask psutil pywin32 pystray pillow --quiet 2>nul
echo Installing music detection (optional)...
pip install winsdk --quiet 2>nul

echo Starting DayTrace in tray...
pythonw tracker.py
