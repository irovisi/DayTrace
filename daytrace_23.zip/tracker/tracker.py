"""
DayTrace — Activity Tracker
Tray icon app: runs in background, right-click to open dashboard or quit.
"""

import sqlite3
import time
import threading
import platform
import os
import sys
import re
import json
import webbrowser
from datetime import datetime, date, timedelta
from pathlib import Path

# ── Storage ───────────────────────────────────────────────────────────────────
DB_PATH = Path.home() / ".daytrace" / "activity.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

PORT = 5700

# ── Settings ──────────────────────────────────────────────────────────────────
# User-editable config stored as JSON next to the database.
# Categories, goals, limits and idle threshold all live here so the
# dashboard can read and rewrite them without touching the database.
SETTINGS_PATH = DB_PATH.parent / "settings.json"

# Idle detection: if no keyboard/mouse input for this many seconds,
# the tracker stops counting time until input returns.
DEFAULT_IDLE_THRESHOLD = 180  # 3 minutes

# Default category for any app the user has not mapped.
DEFAULT_CATEGORY = "Прочее"

# Built-in category assignments by normalised app name.
# The user can override or extend these from the dashboard.
DEFAULT_CATEGORIES = {
    "VS Code":        "Работа",
    "Cursor":         "Работа",
    "IntelliJ IDEA":  "Работа",
    "PyCharm":        "Работа",
    "WebStorm":       "Работа",
    "DataGrip":       "Работа",
    "Rider":          "Работа",
    "Windows Terminal":"Работа",
    "PowerShell":     "Работа",
    "CMD":            "Работа",
    "WSL":            "Работа",
    "Docker":         "Работа",
    "Postman":        "Работа",
    "Insomnia":       "Работа",
    "Python":         "Работа",
    "Node.js":        "Работа",
    "Obsidian":       "Учёба",
    "Notepad++":      "Работа",
    "Figma":          "Работа",
    "Word":           "Работа",
    "Excel":          "Работа",
    "PowerPoint":     "Работа",
    "OneNote":        "Учёба",
    "Outlook":        "Общение",
    "Teams":          "Общение",
    "Slack":          "Общение",
    "Telegram":       "Общение",
    "Discord":        "Общение",
    "Zoom":           "Общение",
    "Chrome":         "Браузер",
    "Edge":           "Браузер",
    "Firefox":        "Браузер",
    "Opera":          "Браузер",
    "Brave":          "Браузер",
    "Vivaldi":        "Браузер",
    "Steam":          "Развлечения",
    "Spotify":        "Развлечения",
    "VLC":            "Развлечения",
    "Apple Music":    "Музыка",
    "Музыка (фон)":   "Музыка",
}

# Built-in category assignments by domain. Substring match, so "youtube.com"
# also covers "m.youtube.com". The user can override these from the dashboard.
DEFAULT_DOMAIN_CATEGORIES = {
    "github.com":       "Работа",
    "gitlab.com":       "Работа",
    "stackoverflow.com":"Работа",
    "habr.com":         "Учёба",
    "learn.microsoft.com":"Учёба",
    "youtube.com":      "Развлечения",
    "twitch.tv":        "Развлечения",
    "netflix.com":      "Развлечения",
    "rezka.ag":         "Развлечения",
    "hdrezka.ag":       "Развлечения",
    "kinopoisk.ru":     "Развлечения",
    "vk.com":           "Общение",
    "t.me":             "Общение",
    "web.telegram.org": "Общение",
    "discord.com":      "Общение",
    "reddit.com":       "Развлечения",
    "twitter.com":      "Развлечения",
    "x.com":            "Развлечения",
    "instagram.com":    "Развлечения",
    "mail.google.com":  "Общение",
    "notion.so":        "Работа",
    "figma.com":        "Работа",
}

DEFAULT_SETTINGS = {
    "idle_threshold": DEFAULT_IDLE_THRESHOLD,
    "idle_enabled":   True,
    # When True, video playing in a browser counts as active even without input.
    "watch_enabled":  True,
    # When True, track background music (Apple Music, Spotify, etc.) via SMTC.
    "music_enabled":  True,
    # When True, track the foreground window on every monitor, not just the
    # one with keyboard focus.
    "multimonitor_enabled": True,
    # Break reminders: notify after N minutes of continuous active work.
    "break_enabled":  True,
    "break_minutes":  50,
    # Limit notifications: send a toast when a rule limit is exceeded.
    "limit_notify_enabled": True,
    # app name -> category name
    "categories":     dict(DEFAULT_CATEGORIES),
    # domain -> category name
    "domain_categories": dict(DEFAULT_DOMAIN_CATEGORIES),
    # list of {"target": "Работа", "type": "category"|"app",
    #          "kind": "goal"|"limit", "seconds": 7200}
    "rules":          [],
}

_settings = None
_settings_lock = threading.Lock()

def load_settings() -> dict:
    """Read settings from disk, falling back to defaults. Cached in memory."""
    global _settings
    with _settings_lock:
        if _settings is not None:
            return _settings
        data = dict(DEFAULT_SETTINGS)
        try:
            if SETTINGS_PATH.exists():
                saved = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
                # Merge so new default keys appear for old config files.
                for k, v in saved.items():
                    data[k] = v
                # Categories: keep user entries, add any new built-in defaults.
                merged_cats = dict(DEFAULT_CATEGORIES)
                merged_cats.update(saved.get("categories", {}))
                data["categories"] = merged_cats
                # Domain categories: same merge strategy.
                merged_dom = dict(DEFAULT_DOMAIN_CATEGORIES)
                merged_dom.update(saved.get("domain_categories", {}))
                data["domain_categories"] = merged_dom
        except Exception:
            pass
        _settings = data
        return _settings

def save_settings(new_data: dict) -> dict:
    """Persist settings to disk and refresh the in-memory cache."""
    global _settings
    with _settings_lock:
        current = _settings if _settings is not None else dict(DEFAULT_SETTINGS)
        current = dict(current)
        for k, v in new_data.items():
            if k == "categories" and isinstance(v, dict):
                # Merge so a partial update never drops existing mappings.
                # An empty-string value removes that mapping (falls back to default).
                merged = dict(current.get("categories", {}))
                for app_name, cat_name in v.items():
                    if cat_name == "":
                        merged.pop(app_name, None)
                    else:
                        merged[app_name] = cat_name
                current["categories"] = merged
            elif k == "domain_categories" and isinstance(v, dict):
                merged = dict(current.get("domain_categories", {}))
                for dom, cat_name in v.items():
                    if cat_name == "":
                        merged.pop(dom, None)
                    else:
                        merged[dom] = cat_name
                current["domain_categories"] = merged
            else:
                current[k] = v
        try:
            SETTINGS_PATH.write_text(
                json.dumps(current, ensure_ascii=False, indent=2),
                encoding="utf-8")
        except Exception:
            pass
        _settings = current
        return _settings

def category_for(app: str) -> str:
    """Resolve an app name to its category using current settings."""
    cats = load_settings().get("categories", {})
    return cats.get(app, DEFAULT_CATEGORY)

def category_for_domain(domain: str) -> str | None:
    """Resolve a domain to its category. Substring match so subdomains work.
    Returns None if the domain has no mapping."""
    if not domain:
        return None
    dom_cats = load_settings().get("domain_categories", {})
    host = domain.split(":")[0].lower()
    if host in dom_cats:
        return dom_cats[host]
    # substring fallback: youtube.com matches m.youtube.com
    for mapped, cat in dom_cats.items():
        if mapped in host or host in mapped:
            return cat
    return None

def category_for_event(app: str, domain: str | None) -> str:
    """Category for a tracked event. A domain category takes priority over the
    browser's app category, so time on sites lands in the right bucket."""
    if domain:
        dom_cat = category_for_domain(domain)
        if dom_cat:
            return dom_cat
    return category_for(app)


def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                ts             INTEGER NOT NULL,
                app            TEXT NOT NULL,
                title          TEXT NOT NULL,
                domain         TEXT,
                obsidian_note  TEXT,
                obsidian_vault TEXT,
                source         TEXT DEFAULT 'focus',
                duration       INTEGER DEFAULT 0
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_ts ON events(ts)")
        cols = {row[1] for row in db.execute("PRAGMA table_info(events)")}
        if "obsidian_note"  not in cols:
            db.execute("ALTER TABLE events ADD COLUMN obsidian_note  TEXT")
        if "obsidian_vault" not in cols:
            db.execute("ALTER TABLE events ADD COLUMN obsidian_vault TEXT")
        if "source" not in cols:
            db.execute("ALTER TABLE events ADD COLUMN source TEXT DEFAULT 'focus'")
        db.commit()

# ── App name normalisation ────────────────────────────────────────────────────
APP_NAMES = {
    "steamwebhelper":   "Steam",
    "steam":            "Steam",
    "steamservice":     "Steam",
    "discord":          "Discord",
    "discordptb":       "Discord PTB",
    "discordcanary":    "Discord Canary",
    "slack":            "Slack",
    "telegram":         "Telegram",
    "obsidian":         "Obsidian",
    "code":             "VS Code",
    "cursor":           "Cursor",
    "idea64":           "IntelliJ IDEA",
    "pycharm64":        "PyCharm",
    "webstorm64":       "WebStorm",
    "datagrip64":       "DataGrip",
    "rider64":          "Rider",
    "notepad++":        "Notepad++",
    "notepad":          "Notepad",
    "explorer":         "Explorer",
    "taskmgr":          "Task Manager",
    "powershell":       "PowerShell",
    "windowsterminal":  "Windows Terminal",
    "cmd":              "CMD",
    "wt":               "Windows Terminal",
    "msedge":           "Edge",
    "chrome":           "Chrome",
    "firefox":          "Firefox",
    "opera":            "Opera",
    "brave":            "Brave",
    "vivaldi":          "Vivaldi",
    "postman":          "Postman",
    "insomnia":         "Insomnia",
    "figma":            "Figma",
    "gimp":             "GIMP",
    "vlc":              "VLC",
    "spotify":          "Spotify",
    "zoom":             "Zoom",
    "teams":            "Teams",
    "msteams":          "Teams",
    "outlook":          "Outlook",
    "winword":          "Word",
    "excel":            "Excel",
    "powerpnt":         "PowerPoint",
    "onenote":          "OneNote",
    "wsl":              "WSL",
    "wslhost":          "WSL",
    "python":           "Python",
    "node":             "Node.js",
    "docker":           "Docker",
}

# Domains excluded from the sites list (local services, DayTrace itself)
EXCLUDED_DOMAINS = {
    "localhost", "127.0.0.1", "0.0.0.0",
    "local", "internal", "lan",
}

def _normalise_app(raw: str) -> str:
    key = raw.lower().replace(".exe", "")
    if key in APP_NAMES:
        return APP_NAMES[key]
    for pattern, name in APP_NAMES.items():
        if pattern in key:
            return name
    return raw.replace(".exe", "").capitalize()

# ── Window detection ──────────────────────────────────────────────────────────
SYSTEM = platform.system()

def get_active_window():
    try:
        if SYSTEM == "Windows":
            import win32gui, win32process, psutil
            hwnd   = win32gui.GetForegroundWindow()
            title  = win32gui.GetWindowText(hwnd)
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            try:
                raw_app = psutil.Process(pid).name()
            except Exception:
                raw_app = "Unknown"
            app = _normalise_app(raw_app)
            return app, title, _extract_domain(app, title), _parse_obsidian(app, title)
        elif SYSTEM == "Darwin":
            import subprocess
            script  = 'tell application "System Events" to return name of first process whose frontmost is true'
            raw_app = subprocess.check_output(["osascript", "-e", script]).decode().strip()
            app     = _normalise_app(raw_app)
            return app, app, None, _parse_obsidian(app, app)
        else:
            import subprocess
            wid     = subprocess.check_output(["xdotool","getactivewindow"],  stderr=subprocess.DEVNULL).decode().strip()
            title   = subprocess.check_output(["xdotool","getwindowname",wid],stderr=subprocess.DEVNULL).decode().strip()
            pid     = subprocess.check_output(["xdotool","getwindowpid",wid], stderr=subprocess.DEVNULL).decode().strip()
            import psutil
            try:
                raw_app = psutil.Process(int(pid)).name()
            except Exception:
                raw_app = title[:20]
            app = _normalise_app(raw_app)
            return app, title, _extract_domain(app, title), _parse_obsidian(app, title)
    except Exception as e:
        return "Unknown", str(e), None, None

# ── Multi-monitor: foreground window per monitor ──────────────────────────────
# GetForegroundWindow returns only the keyboard-focused window. To also capture
# what's visible on other monitors (e.g. a series playing on monitor 2 while you
# work on monitor 1), we enumerate top-level windows, find the topmost visible
# one on each monitor, and report each as a separate source.

def get_windows_per_monitor():
    """
    Returns a list of dicts, one per monitor that has a visible window:
      {"monitor": int, "app": str, "title": str, "domain": str|None,
       "obsidian": dict|None, "focused": bool}
    Windows only. On other systems returns [] (caller falls back to focus only).
    """
    if SYSTEM != "Windows":
        return []
    try:
        import win32gui, win32process, win32api, win32con, psutil
        import ctypes

        foreground = win32gui.GetForegroundWindow()

        # Map each monitor handle to a stable index.
        monitors = win32api.EnumDisplayMonitors()
        mon_index = {}
        for i, (hMon, _hdc, _rect) in enumerate(monitors):
            mon_index[hMon.handle if hasattr(hMon, "handle") else int(hMon)] = i

        # For each monitor keep the first (topmost in Z-order) qualifying window.
        # EnumWindows yields windows in top-to-bottom Z-order.
        seen_monitors = {}

        def _enum(hwnd, _):
            if not win32gui.IsWindowVisible(hwnd):
                return True
            title = win32gui.GetWindowText(hwnd)
            if not title:
                return True
            # Skip tool windows and zero-size windows.
            try:
                l, t, r, b = win32gui.GetWindowRect(hwnd)
                if (r - l) < 100 or (b - t) < 100:
                    return True
            except Exception:
                return True
            try:
                hMon = win32api.MonitorFromWindow(hwnd, win32con.MONITOR_DEFAULTTONULL)
                if not hMon:
                    return True
                key = hMon.handle if hasattr(hMon, "handle") else int(hMon)
                idx = mon_index.get(key, 0)
            except Exception:
                idx = 0
            if idx in seen_monitors:
                return True  # already have the topmost window for this monitor
            try:
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                raw_app = psutil.Process(pid).name()
            except Exception:
                return True
            app = _normalise_app(raw_app)
            seen_monitors[idx] = {
                "monitor":  idx,
                "app":      app,
                "title":    title,
                "domain":   _extract_domain(app, title),
                "obsidian": _parse_obsidian(app, title),
                "focused":  hwnd == foreground,
            }
            return True

        win32gui.EnumWindows(_enum, None)
        return list(seen_monitors.values())
    except Exception:
        return []

# ── Background music detection via SMTC ───────────────────────────────────────
# System Media Transport Controls expose the now-playing media session (the same
# data Windows shows on the volume/now-playing flyout). Apple Music, Spotify,
# browsers, etc. all report through it. We read the session WITHOUT extra pip
# dependencies if the WinRT bindings ship with the Python install; otherwise we
# degrade to "no music" gracefully.

_music_cache = {"value": None, "ts": 0.0}
_MUSIC_CACHE_TTL = 5.0

def get_now_playing():
    """
    Returns {"app": str, "title": str, "artist": str} for the currently PLAYING
    media session, or None. Cached for a few seconds. Windows only.
    """
    if SYSTEM != "Windows":
        return None
    now = time.time()
    if now - _music_cache["ts"] < _MUSIC_CACHE_TTL:
        return _music_cache["value"]

    result = None
    try:
        # WinRT bindings: either the modern 'winrt' or the newer 'winsdk' package.
        try:
            from winrt.windows.media.control import (
                GlobalSystemMediaTransportControlsSessionManager as MgrW)
            from winrt.windows.media.control import (
                GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status)
        except ImportError:
            from winsdk.windows.media.control import (
                GlobalSystemMediaTransportControlsSessionManager as MgrW)
            from winsdk.windows.media.control import (
                GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status)
        import asyncio

        async def _read():
            mgr = await MgrW.request_async()
            session = mgr.get_current_session()
            if session is None:
                return None
            info = session.get_playback_info()
            # 4 == Playing
            if info is None or int(info.playback_status) != 4:
                return None
            props = await session.try_get_media_properties_async()
            app_id = session.source_app_user_model_id or "Музыка"
            return {
                "app_id": app_id,
                "title":  (props.title or "").strip() if props else "",
                "artist": (props.artist or "").strip() if props else "",
            }

        try:
            loop = asyncio.new_event_loop()
            data = loop.run_until_complete(_read())
            loop.close()
        except Exception:
            data = None

        if data:
            result = {
                "app":    _normalise_music_app(data["app_id"]),
                "title":  data["title"],
                "artist": data["artist"],
            }
    except Exception:
        result = None

    _music_cache["value"] = result
    _music_cache["ts"]    = now
    return result

def _normalise_music_app(app_id: str) -> str:
    """Map an SMTC source app id to a friendly name."""
    low = (app_id or "").lower()
    if "apple" in low or "applemusic" in low:
        return "Apple Music"
    if "spotify" in low:
        return "Spotify"
    if "chrome" in low:
        return "Музыка (Chrome)"
    if "msedge" in low or "edge" in low:
        return "Музыка (Edge)"
    if "firefox" in low:
        return "Музыка (Firefox)"
    if "zune" in low or "media" in low:
        return "Музыка (Media Player)"
    if "yandex" in low or "music.yandex" in low:
        return "Яндекс Музыка"
    if "vlc" in low:
        return "VLC"
    # fall back to a generic background-music bucket
    return "Музыка (фон)"

# ── Idle detection ────────────────────────────────────────────────────────────
def get_idle_seconds() -> float:
    """
    Seconds since the last keyboard or mouse input.
    Windows: GetLastInputInfo (no extra dependency, no global hooks).
    Other systems: returns 0.0 so tracking is never blocked there.
    """
    if SYSTEM == "Windows":
        try:
            import ctypes
            class LASTINPUTINFO(ctypes.Structure):
                _fields_ = [("cbSize", ctypes.c_uint),
                            ("dwTime", ctypes.c_uint)]
            info = LASTINPUTINFO()
            info.cbSize = ctypes.sizeof(LASTINPUTINFO)
            if ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
                millis = ctypes.windll.kernel32.GetTickCount() - info.dwTime
                return millis / 1000.0
        except Exception:
            return 0.0
    return 0.0

# ── Video playback detection (browser) ────────────────────────────────────────
# Goal: when you watch video in a browser you stop touching the mouse/keyboard,
# so idle detection would freeze your time. A playing video makes Windows keep
# the display awake (a DisplayRequired power request). We detect that and treat
# the window as active even without input.
#
# Primary signal: parse `powercfg /requests` DISPLAY section for a browser exe.
#   Accurate, but the command may need admin; if it fails we degrade safely.
# The result is cached so we don't spawn a process on every 2-second poll.

_BROWSER_EXES = {
    "chrome.exe", "msedge.exe", "firefox.exe", "opera.exe",
    "brave.exe", "vivaldi.exe", "chromium.exe", "arc.exe",
}

_playback_cache = {"value": False, "ts": 0.0}
_PLAYBACK_CACHE_TTL = 8  # seconds; powercfg is relatively expensive to spawn

def _parse_powercfg_display(text: str) -> bool:
    """True if the DISPLAY power-request section names a browser process.
    Handles English ('DISPLAY:') and Russian ('ДИСПЛЕЙ:') Windows locales."""
    # Match the display section header in either locale, capture until the
    # next ALL-CAPS header (Latin or Cyrillic) or end of text.
    m = re.search(
        r"(?:DISPLAY|ДИСПЛЕЙ|ЭКРАН):\s*(.*?)(?:\n[A-ZА-Я]{3,}:|\Z)",
        text, re.S | re.I)
    if not m:
        return False
    block = m.group(1)
    low = block.lower()
    if not any(exe in low for exe in _BROWSER_EXES):
        return False
    return True

def is_browser_playing_video() -> bool:
    """
    Best-effort detection that a browser is keeping the display awake,
    i.e. video is playing. Cached for a few seconds. Safe default: False.
    """
    if SYSTEM != "Windows":
        return False
    now = time.time()
    if now - _playback_cache["ts"] < _PLAYBACK_CACHE_TTL:
        return _playback_cache["value"]

    result = False
    try:
        import subprocess
        # CREATE_NO_WINDOW (0x08000000) keeps a console from flashing.
        out = subprocess.run(
            ["powercfg", "/requests"],
            capture_output=True, text=True, timeout=4,
            creationflags=0x08000000,
        )
        combined = (out.stdout or "") + (out.stderr or "")
        if combined.strip():
            result = _parse_powercfg_display(combined)
    except Exception:
        result = False

    _playback_cache["value"] = result
    _playback_cache["ts"]    = now
    return result

# ── Domain detection ──────────────────────────────────────────────────────────
BROWSERS = {"chrome","firefox","edge","opera","brave","vivaldi","arc","chromium","safari"}

# Strips browser name appended to every tab title: "Page Title - Chrome"
_BROWSER_SUFFIX = re.compile(
    r"\s*[-\u2013]\s*(Google Chrome|Chrome|Firefox|Microsoft Edge|Edge|Opera|Brave|Vivaldi|Safari)\s*$",
    re.I
)

def _extract_domain(app: str, title: str):
    if not any(b in app.lower() for b in BROWSERS):
        return None
    domain = _parse_domain(title)
    if domain:
        host = domain.split(":")[0].lower()
        if host in EXCLUDED_DOMAINS or host.startswith("127.") or host.startswith("192.168."):
            return None
        return domain
    # Title gave nothing — try reading the last URL from browser history.
    if SYSTEM == "Windows":
        return _domain_from_history(app)
    return None

def _parse_domain(title: str):
    """
    Extract domain from browser window title.
    Strips browser suffix first to avoid false matches on "Google Chrome" -> google.com.
    """
    # Bare titles that mean "no real page open"
    if title.strip().lower() in {"google", "google chrome", "new tab", ""}:
        return None

    # Strip trailing browser name to get the actual page title
    page = _BROWSER_SUFFIX.sub("", title).strip()

    if not page or page.lower() in {"new tab", "google chrome", "chrome", "firefox", "edge", "opera", "brave"}:
        return None

    # Explicit domain in title (most reliable)
    m = re.search(
        r"([\w\-]+\.(com|net|org|io|dev|ru|ua|co|app|ai|me|gov|edu|uk|de|fr|jp|tv|gg|by|cz|pl|se|no|fi))",
        page, re.I
    )
    if m:
        return m.group(1).lower()

    # Known sites matched against page title only, with word boundaries
    known = {
        "github":    "github.com",
        "youtube":   "youtube.com",
        "gmail":     "mail.google.com",
        "google":    "google.com",
        "reddit":    "reddit.com",
        "twitter":   "twitter.com",
        "facebook":  "facebook.com",
        "instagram": "instagram.com",
        "linkedin":  "linkedin.com",
        "twitch":    "twitch.tv",
        "telegram":  "web.telegram.org",
        "habr":      "habr.com",
        "notion":    "notion.so",
        "figma":     "figma.com",
        "discord":   "discord.com",
        "vk":        "vk.com",
        "trello":    "trello.com",
        "jira":      "atlassian.net",
    }
    tl = page.lower()
    for keyword, domain in known.items():
        if re.search(r"\b" + re.escape(keyword) + r"\b", tl):
            return domain
    return None

# ── Browser history domain fallback ──────────────────────────────────────────
# Pasting a URL into the title extractor doesn't work for piracy/obscure sites
# that put no domain in the tab title. Fallback: read the last visited URL
# directly from Chrome's SQLite history file (no extension needed).
# The file is locked while Chrome runs, but Windows allows copying it.
import shutil, tempfile as _tempfile
from urllib.parse import urlparse as _urlparse

_CHROME_HISTORY_PATHS = [
    Path.home() / "AppData/Local/Google/Chrome/User Data/Default/History",
    Path.home() / "AppData/Local/Microsoft/Edge/User Data/Default/History",
    Path.home() / "AppData/Roaming/Opera Software/Opera Stable/History",
    Path.home() / "AppData/Local/BraveSoftware/Brave-Browser/User Data/Default/History",
]

# Cache: (app, title) -> domain, refreshed every few seconds.
_history_cache: dict = {}
_history_cache_ts: float = 0.0
_HISTORY_CACHE_TTL = 5.0   # seconds

def _domain_from_history(app: str) -> str | None:
    """
    Copy the browser history DB to a temp file and return the domain of the
    most recently visited URL. Returns None on any error.
    """
    global _history_cache, _history_cache_ts
    now = time.time()
    if now - _history_cache_ts < _HISTORY_CACHE_TTL:
        return _history_cache.get("domain")

    result = None
    try:
        app_low = app.lower()
        # pick the right history file for the active browser
        hist_path = None
        for p in _CHROME_HISTORY_PATHS:
            name = p.parts[-4].lower() if len(p.parts) >= 4 else ""
            if ("edge" in name and "edge" in app_low) or \
               ("brave" in name and "brave" in app_low) or \
               ("opera" in name and "opera" in app_low) or \
               ("chrome" in name and ("chrome" in app_low or "chromium" in app_low)):
                if p.exists():
                    hist_path = p
                    break
        # fallback: first existing file
        if hist_path is None:
            for p in _CHROME_HISTORY_PATHS:
                if p.exists():
                    hist_path = p
                    break
        if hist_path is None:
            return None

        tmp = Path(_tempfile.mktemp(suffix=".db"))
        shutil.copy2(str(hist_path), str(tmp))
        try:
            conn = sqlite3.connect(str(tmp))
            row = conn.execute(
                "SELECT u.url FROM urls u "
                "JOIN visits v ON u.id = v.url "
                "ORDER BY v.visit_time DESC LIMIT 1"
            ).fetchone()
            conn.close()
            if row:
                parsed = _urlparse(row[0])
                host = (parsed.hostname or "").lower()
                if host.startswith("www."):
                    host = host[4:]
                if host and host not in EXCLUDED_DOMAINS \
                        and not host.startswith("127.") \
                        and not host.startswith("192.168."):
                    result = host
        finally:
            try:
                tmp.unlink()
            except Exception:
                pass
    except Exception:
        result = None

    _history_cache = {"domain": result}
    _history_cache_ts = now
    return result


def _parse_obsidian(app: str, title: str):
    """
    Returns {'note': str, 'vault': str|None} or None.
    Handles all Obsidian title formats:
      'Note - Vault - Obsidian 1.12.7'
      'Note - Obsidian 1.12.7'          (single-vault, no vault name shown)
      'Note With Dashes - Part2 - Vault - Obsidian 1.12.7'
    Splits only on spaced dashes (' - ') to preserve dates like '2024-06-22'.

    Key fix: when the vault name is omitted from the title (single-vault setup),
    Obsidian shows "Note Name - Obsidian X.X". If the note name itself contains
    ' - ', the naive last-part-is-vault heuristic cuts it wrong.
    We validate against known vault files to recover the correct split.
    """
    if "obsidian" not in app.lower() and "obsidian" not in title.lower():
        return None

    # Strip " - Obsidian [anything]" from end
    clean = re.sub(r"\s+[-\u2013\u2014]\s+Obsidian\b.*$", "", title, flags=re.I).strip()

    if not clean or re.fullmatch(r"Obsidian.*", clean, re.I):
        return None

    # Split on spaced dashes only (preserves "2024-06-22" in note names)
    parts = [p.strip() for p in re.split(r"\s+[-\u2013\u2014]\s+", clean) if p.strip()]

    if len(parts) == 0:
        return None
    if len(parts) == 1:
        note, vault = parts[0], None
    else:
        # Try to find the longest prefix that matches a real vault file.
        # This fixes the case where vault name is absent and note name has ' - '.
        known = set(_scan_vault_notes())  # cached, near-free
        if known:
            # First check if the entire clean string is a known note
            # (happens when vault name is not shown in title at all)
            if clean in known:
                note, vault = clean, None
            else:
                # Walk from longest candidate down to shortest
                best_note = None
                best_vault = None
                for split_at in range(len(parts) - 1, 0, -1):
                    candidate = " - ".join(parts[:split_at])
                    if candidate in known:
                        best_note  = candidate
                        best_vault = parts[split_at] if split_at < len(parts) else None
                        break
                if best_note:
                    note  = best_note
                    vault = best_vault
                else:
                    # No match found: fall back to naive heuristic
                    vault = parts[-1]
                    note  = " - ".join(parts[:-1])
        else:
            # No vault scanned yet: naive heuristic
            vault = parts[-1]
            note  = " - ".join(parts[:-1])

    # Home screen guard
    if re.match(r"^Obsidian\b", note, re.I):
        return None

    return {"note": note, "vault": vault}

# ── Windows notifications ─────────────────────────────────────────────────────
# Toasts require a *registered* AppUserModelID. A made-up id like "DayTrace"
# is silently dropped by Windows. We use PowerShell's own always-registered id.
_PS_APP_ID = r"{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe"

def _send_notification(title: str, body: str) -> None:
    """
    Show a Windows toast using PowerShell with its registered AppID.
    The script is written to a temp .ps1 file (UTF-8 with BOM) so Cyrillic
    text survives. Silent on any failure.
    """
    if SYSTEM != "Windows":
        return

    # Escape single quotes for PowerShell string literals.
    t = title.replace("'", "''")
    b = body.replace("'", "''")

    ps_script = f"""
$ErrorActionPreference = 'Stop'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$texts = $template.GetElementsByTagName('text')
$texts.Item(0).AppendChild($template.CreateTextNode('{t}')) | Out-Null
$texts.Item(1).AppendChild($template.CreateTextNode('{b}')) | Out-Null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
$appId = '{_PS_APP_ID}'
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId).Show($toast)
"""
    try:
        import subprocess, tempfile
        # Write as UTF-8 with BOM so PowerShell reads Cyrillic correctly.
        fd, path = tempfile.mkstemp(suffix=".ps1")
        with os.fdopen(fd, "wb") as f:
            f.write(b"\xef\xbb\xbf")           # UTF-8 BOM
            f.write(ps_script.encode("utf-8"))
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
             "-WindowStyle", "Hidden", "-File", path],
            timeout=10, creationflags=0x08000000, capture_output=True)
        try:
            os.unlink(path)
        except Exception:
            pass
    except Exception:
        pass

# ── Break reminder ────────────────────────────────────────────────────────────
_break_active_seconds = 0       # seconds of continuous non-idle time
_break_notified       = False   # True once we've sent the break notification
                                # reset when user goes idle (takes a break)

def _update_break(elapsed: int, cfg: dict) -> None:
    """Called each active tick. Sends break reminder when threshold reached."""
    global _break_active_seconds, _break_notified
    if not cfg.get("break_enabled", True):
        _break_active_seconds = 0
        _break_notified = False
        return
    threshold = cfg.get("break_minutes", 50) * 60
    _break_active_seconds += elapsed
    if _break_active_seconds >= threshold and not _break_notified:
        mins = cfg.get("break_minutes", 50)
        _send_notification(
            "Время сделать перерыв",
            f"Ты работаешь уже {mins} минут без остановки. Встань, разомнись.")
        _break_notified = True

def _reset_break() -> None:
    """Called when the user goes idle — they took a break, reset the counter."""
    global _break_active_seconds, _break_notified
    _break_active_seconds = 0
    _break_notified = False

# ── Limit notifications ───────────────────────────────────────────────────────
# We check limits at most once per minute to avoid hammering the DB.
_limit_last_check  = 0.0
_limit_notified: set = set()   # rule targets already notified today
_limit_last_day: int = -1      # day-of-year; resets notified set daily
_LIMIT_CHECK_INTERVAL = 60     # seconds

def _check_limits(cfg: dict) -> None:
    """
    Query today's totals and send a notification when a limit rule is exceeded
    for the first time today. Runs at most once per minute.
    """
    global _limit_last_check, _limit_notified, _limit_last_day
    if not cfg.get("limit_notify_enabled", True):
        return
    rules = [r for r in cfg.get("rules", []) if r.get("kind") == "limit"]
    if not rules:
        return
    now = time.time()
    if now - _limit_last_check < _LIMIT_CHECK_INTERVAL:
        return
    _limit_last_check = now

    # Reset per-day tracking at midnight
    today_yday = time.localtime().tm_yday
    if today_yday != _limit_last_day:
        _limit_notified.clear()
        _limit_last_day = today_yday

    try:
        start, end = _day_bounds()
        with get_db() as db:
            rows = db.execute(
                "SELECT app, domain, source, SUM(duration) as dur "
                "FROM events WHERE ts BETWEEN ? AND ? "
                "GROUP BY app, domain, source",
                (start, end)).fetchall()
    except Exception:
        return

    PRIMARY = {"focus", "mon0"}
    apps: dict  = {}
    cats: dict  = {}
    doms: dict  = {}

    for r in rows:
        src = r["source"] or "focus"
        if src not in PRIMARY:
            continue
        apps[r["app"]] = apps.get(r["app"], 0) + (r["dur"] or 0)
        cat = category_for_event(r["app"], r["domain"])
        cats[cat] = cats.get(cat, 0) + (r["dur"] or 0)
        if r["domain"]:
            doms[r["domain"]] = doms.get(r["domain"], 0) + (r["dur"] or 0)

    for rule in rules:
        tgt = rule.get("target")
        typ = rule.get("type", "category")
        limit_sec = rule.get("seconds", 0)
        if tgt in _limit_notified:
            continue
        if typ == "category":
            current = cats.get(tgt, 0)
        elif typ == "app":
            current = apps.get(tgt, 0)
        elif typ == "domain":
            current = doms.get(tgt, 0)
        else:
            continue
        if current > limit_sec:
            h = limit_sec // 3600
            m = (limit_sec % 3600) // 60
            limit_str = f"{h}ч {m}м" if h else f"{m}м"
            cur_h = current // 3600
            cur_m = (current % 3600) // 60
            cur_str = f"{cur_h}ч {cur_m}м" if cur_h else f"{cur_m}м"
            _send_notification(
                f"Лимит превышен: {tgt}",
                f"Потрачено {cur_str} из {limit_str}.")
            _limit_notified.add(tgt)

# ── Tracker loop ──────────────────────────────────────────────────────────────
_last_app      = None
_last_title    = None
_last_ts       = None
_running       = False
_is_idle       = False
_is_watching   = False
_is_music      = False
_music_label   = None
# Per-source last event: source_key -> {"id", "app", "title", "domain"}
_last_events: dict = {}
_lock          = threading.Lock()
POLL_INTERVAL  = 2

def _upsert_event(db, source, app, title, domain, obs_note, obs_vault, now, elapsed):
    """Insert a new event for a source, or extend the existing one if the
    (app, title, domain) is unchanged. Keeps one running row per source."""
    prev = _last_events.get(source)
    if prev and prev["app"] == app and prev["title"] == title and prev["domain"] == domain:
        inc = elapsed if 0 < elapsed <= POLL_INTERVAL * 3 else POLL_INTERVAL
        db.execute("UPDATE events SET duration = duration + ? WHERE id = ?",
                   (inc, prev["id"]))
    else:
        cur = db.execute(
            "INSERT INTO events (ts,app,title,domain,obsidian_note,obsidian_vault,source,duration) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (now, app, title, domain, obs_note, obs_vault, source, POLL_INTERVAL))
        _last_events[source] = {"id": cur.lastrowid, "app": app, "title": title, "domain": domain}

def _tracker_loop():
    global _last_app, _last_title, _last_ts, _running
    global _is_idle, _is_watching, _is_music, _music_label, _last_events
    # One persistent connection for the whole loop instead of opening
    # and closing a connection on every poll.
    db = sqlite3.connect(str(DB_PATH))
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=NORMAL")
    try:
        while _running:
            try:
                cfg = load_settings()
                idle_on    = cfg.get("idle_enabled", True)
                idle_max   = cfg.get("idle_threshold", DEFAULT_IDLE_THRESHOLD)
                watch_on   = cfg.get("watch_enabled", True)
                music_on   = cfg.get("music_enabled", True)
                multimon   = cfg.get("multimonitor_enabled", True)

                # Focused window first (always tracked, drives idle logic).
                app, title, domain, obsidian = get_active_window()
                obs_note  = obsidian["note"]  if obsidian else None
                obs_vault = obsidian["vault"] if obsidian else None

                idle_secs  = get_idle_seconds()
                is_browser = any(b in app.lower() for b in BROWSERS)

                # Watch mode: any browser keeping the display awake means video is
                # playing somewhere (incl. a second monitor), so it's not idle.
                watching = False
                if watch_on and idle_on and idle_secs >= idle_max:
                    watching = is_browser_playing_video()

                # Music: read once per tick (cached internally).
                now_playing = get_now_playing() if music_on else None

                # If truly idle (no input, no video) we still let music keep
                # recording, because you can listen with the screen idle.
                truly_idle = idle_on and idle_secs >= idle_max and not watching

                now = int(time.time())
                with _lock:
                    _is_watching = watching
                    _is_music    = now_playing is not None
                    _music_label = (now_playing["app"] if now_playing else None)

                    if truly_idle:
                        # Foreground/monitor sources freeze. Forget their running
                        # rows so the gap never leaks when you come back.
                        _is_idle = True
                        for k in [k for k in _last_events if k != "music"]:
                            _last_events.pop(k, None)
                        _last_ts = None
                        # Break counter resets when user goes idle (took a break).
                        _reset_break()
                        # Music keeps going even while the screen is idle.
                        if now_playing:
                            mtitle = _music_title(now_playing)
                            _upsert_event(db, "music", now_playing["app"], mtitle,
                                          None, None, None, now, POLL_INTERVAL)
                            db.commit()
                        time.sleep(POLL_INTERVAL)
                        continue

                    _is_idle = False
                    elapsed = now - _last_ts if _last_ts is not None else POLL_INTERVAL

                    # Break reminder: accumulate active time.
                    _update_break(min(elapsed, POLL_INTERVAL * 3), cfg)

                    # Limit notifications: checked at most once per minute.
                    _check_limits(cfg)

                    # Build the set of active window sources for this tick.
                    if multimon:
                        wins = get_windows_per_monitor()
                    else:
                        wins = []
                    if not wins:
                        # Fall back to the single focused window as monitor 0.
                        wins = [{"monitor": 0, "app": app, "title": title,
                                 "domain": domain, "obsidian": obsidian, "focused": True}]

                    active_sources = set()
                    secondary_idx = 1
                    for w in wins:
                        # The focused window is always "mon0" (primary),
                        # regardless of its physical monitor number.
                        # This prevents mis-classification when Windows
                        # enumerates monitors in a non-intuitive order.
                        if w.get("focused"):
                            src = "mon0"
                        else:
                            src = f"mon{secondary_idx}"
                            secondary_idx += 1
                        active_sources.add(src)
                        wobs = w.get("obsidian")
                        wn = wobs["note"]  if wobs else None
                        wv = wobs["vault"] if wobs else None
                        _upsert_event(db, src, w["app"], w["title"], w["domain"],
                                      wn, wv, now, elapsed)

                    # Music as its own source.
                    if now_playing:
                        active_sources.add("music")
                        mtitle = _music_title(now_playing)
                        _upsert_event(db, "music", now_playing["app"], mtitle,
                                      None, None, None, now, elapsed)

                    # Drop running rows for sources no longer active so their next
                    # appearance starts a fresh row.
                    for k in [k for k in _last_events if k not in active_sources]:
                        _last_events.pop(k, None)

                    db.commit()
                    _last_ts    = now
                    _last_app   = app
                    _last_title = title
            except Exception:
                pass
            time.sleep(POLL_INTERVAL)
    finally:
        db.close()

def _music_title(now_playing) -> str:
    """Compose a readable title for a music event."""
    artist = now_playing.get("artist") or ""
    title  = now_playing.get("title")  or ""
    if artist and title:
        return f"{artist} — {title}"
    return title or artist or "—"

def start_tracker():
    global _running
    if not _running:
        _running = True
        threading.Thread(target=_tracker_loop, daemon=True).start()

def stop_tracker():
    global _running
    _running = False

# ── Obsidian export ───────────────────────────────────────────────────────────
_obsidian_vault_path: Path | None = None
_vault_search_done = False  # remember we already searched, even if nothing found

def _find_obsidian_vault() -> Path | None:
    """Auto-detect Obsidian vault by reading Obsidian's own config first,
    then falling back to a shallow folder scan. Result is cached."""
    global _vault_search_done
    # Obsidian stores the list of known vaults here. Reading it is instant
    # and avoids scanning the whole disk.
    try:
        import json
        cfg = Path.home() / "AppData" / "Roaming" / "obsidian" / "obsidian.json"
        if cfg.exists():
            data = json.loads(cfg.read_text(encoding="utf-8"))
            for v in data.get("vaults", {}).values():
                p = Path(v.get("path", ""))
                if p.exists() and (p / ".obsidian").is_dir():
                    return p
    except Exception:
        pass

    # Fallback: shallow scan of common roots only (max 3 levels deep),
    # never the entire C:/Users tree.
    search_roots = [
        Path.home() / "Documents",
        Path.home() / "Desktop",
        Path.home(),
    ]
    for root in search_roots:
        if not root.exists():
            continue
        try:
            for depth_dir in [root, *[d for d in root.iterdir() if d.is_dir()]]:
                candidate = depth_dir / ".obsidian"
                if candidate.is_dir():
                    return depth_dir
        except (PermissionError, OSError):
            continue
    _vault_search_done = True
    return None

def set_vault_path(path: str):
    global _obsidian_vault_path
    _obsidian_vault_path = Path(path)

# ── Vault note scanner ────────────────────────────────────────────────────────
# Scan all .md files in the vault so the settings UI can offer every note
# as a goal target — even before the note has ever been opened in Obsidian.
_vault_notes_cache: list = []
_vault_notes_cache_ts: float = 0.0
_VAULT_NOTES_TTL = 60.0   # re-scan at most once per minute

# Folders Obsidian uses internally; skip them during scan.
_OBSIDIAN_SKIP_DIRS = {".obsidian", ".trash", "node_modules", ".git"}

def _scan_vault_notes() -> list[str]:
    """
    Return a sorted list of note names (filename without .md) from the vault.
    Result is cached for _VAULT_NOTES_TTL seconds. Returns [] on any error.
    """
    global _vault_notes_cache, _vault_notes_cache_ts
    now = time.time()
    if now - _vault_notes_cache_ts < _VAULT_NOTES_TTL and _vault_notes_cache:
        return _vault_notes_cache

    vp = _obsidian_vault_path or _find_obsidian_vault()
    if vp is None:
        return []

    names: list[str] = []
    try:
        for md in Path(vp).rglob("*.md"):
            # Skip hidden dirs and Obsidian system dirs at any level.
            if any(part in _OBSIDIAN_SKIP_DIRS or part.startswith(".")
                   for part in md.parts):
                continue
            names.append(md.stem)   # filename without .md extension
    except Exception:
        return []

    names.sort(key=str.lower)
    _vault_notes_cache = names
    _vault_notes_cache_ts = now
    return names

def _build_daily_note(target_date: date) -> str:
    """Build markdown content for a daily summary note."""
    start = int(datetime(target_date.year, target_date.month, target_date.day, 0, 0, 0).timestamp())
    end   = int(datetime(target_date.year, target_date.month, target_date.day, 23, 59, 59).timestamp())

    with get_db() as db:
        rows = db.execute(
            "SELECT app,domain,obsidian_note,obsidian_vault,source,duration "
            "FROM events WHERE ts BETWEEN ? AND ?",
            (start, end)).fetchall()

    if not rows:
        return None

    PRIMARY = {"focus", "mon0"}
    total = sum(r["duration"] for r in rows
                if (r["source"] or "focus") in PRIMARY)

    apps, domains, obs_notes, cats, music = {}, {}, {}, {}, {}
    secondary_apps = {}

    for r in rows:
        src = r["source"] or "focus"
        if src == "music":
            music[r["app"]] = music.get(r["app"], 0) + r["duration"]
            cats["Музыка"] = cats.get("Музыка", 0) + r["duration"]
            continue
        if src not in PRIMARY:
            secondary_apps[r["app"]] = secondary_apps.get(r["app"], 0) + r["duration"]
            continue
        apps[r["app"]] = apps.get(r["app"], 0) + r["duration"]
        cat = category_for_event(r["app"], r["domain"])
        cats[cat] = cats.get(cat, 0) + r["duration"]
        if r["domain"]:
            domains[r["domain"]] = domains.get(r["domain"], 0) + r["duration"]
        if r["obsidian_note"]:
            key = r["obsidian_note"]
            if key not in obs_notes:
                obs_notes[key] = {"note": key, "vault": r["obsidian_vault"], "seconds": 0}
            obs_notes[key]["seconds"] += r["duration"]

    def fmt(sec):
        h = sec // 3600
        m = (sec % 3600) // 60
        if h > 0:
            return f"{h}ч {m}м"
        return f"{m}м" if m > 0 else f"{sec}с"

    lines = []
    lines.append("")
    lines.append(f"Всего за день: **{fmt(total)}**")
    lines.append("")

    # Goals & limits with end-of-day status.
    rules = load_settings().get("rules", [])
    if rules:
        obs_seconds = {k: v["seconds"] for k, v in obs_notes.items()}
        goal_lines, limit_lines = [], []
        for rule in rules:
            tgt  = rule.get("target")
            typ  = rule.get("type", "category")
            if typ == "category":
                sec = cats.get(tgt, 0)
            elif typ == "app":
                sec = apps.get(tgt, 0)
            elif typ == "domain":
                sec = domains.get(tgt, 0)
            elif typ == "obsidian":
                sec = obs_seconds.get(tgt, 0)
            else:
                sec = 0
            target_sec = rule.get("seconds", 0)
            kind = rule.get("kind", "goal")
            if kind == "goal":
                done = sec >= target_sec
                mark = "✅" if done else "❌"
                goal_lines.append(f"- {mark} **{tgt}** — {fmt(sec)} из {fmt(target_sec)}")
            else:
                breached = sec > target_sec
                mark = "⚠️" if breached else "✅"
                status = "превышен" if breached else "в норме"
                limit_lines.append(f"- {mark} **{tgt}** — {fmt(sec)} из {fmt(target_sec)} ({status})")

        if goal_lines or limit_lines:
            lines.append("## Цели и лимиты")
            lines.append("")
            if goal_lines:
                lines.append("**Цели:**")
                lines.append("")
                lines.extend(goal_lines)
                lines.append("")
            if limit_lines:
                lines.append("**Лимиты:**")
                lines.append("")
                lines.extend(limit_lines)
                lines.append("")

    if cats:
        lines.append("## Категории")
        lines.append("")
        for cat, sec in sorted(cats.items(), key=lambda x: x[1], reverse=True):
            lines.append(f"- **{cat}** — {fmt(sec)}")
        lines.append("")

    lines.append("## Приложения")
    lines.append("")
    top_apps = sorted(apps.items(), key=lambda x: x[1], reverse=True)[:10]
    for app, sec in top_apps:
        lines.append(f"- **{app}** — {fmt(sec)}")
    lines.append("")

    if domains:
        lines.append("## Сайты")
        lines.append("")
        top_domains = sorted(domains.items(), key=lambda x: x[1], reverse=True)[:10]
        for domain, sec in top_domains:
            lines.append(f"- {domain} — {fmt(sec)}")
        lines.append("")

    if music:
        lines.append("## Музыка")
        lines.append("")
        for m_app, sec in sorted(music.items(), key=lambda x: x[1], reverse=True):
            lines.append(f"- {m_app} — {fmt(sec)}")
        lines.append("")

    if obs_notes:
        lines.append("## Заметки Obsidian")
        lines.append("")
        top_obs = sorted(obs_notes.values(), key=lambda x: x["seconds"], reverse=True)
        for item in top_obs:
            vault_str = f" *({item['vault']})*" if item["vault"] else ""
            lines.append(f"- [[{item['note']}]]{vault_str} — {fmt(item['seconds'])}")
        lines.append("")

    if secondary_apps:
        lines.append("## Второй монитор")
        lines.append("")
        for app, sec in sorted(secondary_apps.items(), key=lambda x: x[1], reverse=True)[:10]:
            lines.append(f"- {app} — {fmt(sec)}")
        lines.append("")

    return "\n".join(lines)


def export_today_to_obsidian(vault_path: Path = None) -> str:
    """
    Write today's summary to <vault>/Time/DD.MM.md
    Returns: path written, or error string.
    """
    vp = vault_path or _obsidian_vault_path
    if vp is None:
        vp = _find_obsidian_vault()
        if vp is not None:
            set_vault_path(str(vp))  # cache so next export skips the scan
    if vp is None:
        return "error: vault not found"

    target = date.today()
    content = _build_daily_note(target)
    if content is None:
        return "error: no data for today"

    folder = Path(vp) / "Time"
    folder.mkdir(parents=True, exist_ok=True)
    filename = target.strftime("%d.%m") + ".md"
    filepath = folder / filename
    filepath.write_text(content, encoding="utf-8")
    return str(filepath)


# Auto-export: every 10 minutes during the day + hard write at 23:59
_last_export_date:   date | None = None
_last_export_minute: int  | None = None  # last minute-of-day we wrote

def _auto_export_loop():
    global _last_export_date, _last_export_minute
    while True:
        try:
            now_dt = datetime.now()
            today  = now_dt.date()
            minute_of_day = now_dt.hour * 60 + now_dt.minute

            # First run: export today immediately.
            if _last_export_date is None:
                export_today_to_obsidian()
                _last_export_date   = today
                _last_export_minute = minute_of_day

            # New calendar day: export the previous day's note once.
            elif _last_export_date != today:
                from datetime import timedelta
                export_today_to_obsidian.__wrapped__ = getattr(
                    export_today_to_obsidian, '__wrapped__', None)
                _export_for_date(today - timedelta(days=1))
                _last_export_date   = today
                _last_export_minute = None

            else:
                # Within same day: export every 10 minutes or exactly at 23:59.
                is_midnight_slot = (now_dt.hour == 23 and now_dt.minute == 59)
                minutes_since = (minute_of_day - (_last_export_minute or 0))
                due = minutes_since >= 10 or is_midnight_slot

                if due and _last_export_minute != minute_of_day:
                    export_today_to_obsidian()
                    _last_export_date   = today
                    _last_export_minute = minute_of_day

        except Exception:
            pass
        time.sleep(30)  # check twice per minute for the 23:59 slot


def _export_for_date(target: date):
    """Export a specific date's note (used for previous-day export at midnight)."""
    vp = _obsidian_vault_path or _find_obsidian_vault()
    if vp is None:
        return
    content = _build_daily_note(target)
    if content is None:
        return
    folder = Path(vp) / "Time"
    folder.mkdir(parents=True, exist_ok=True)
    filepath = folder / (target.strftime("%d.%m") + ".md")
    filepath.write_text(content, encoding="utf-8")

# ── Flask API ─────────────────────────────────────────────────────────────────
from flask import Flask, jsonify, send_from_directory, request

flask_app = Flask(__name__, static_folder=str(Path(__file__).parent / "static"))

def _day_bounds(target_date=None):
    d = target_date or date.today()
    s = int(datetime(d.year, d.month, d.day, 0, 0, 0).timestamp())
    e = int(datetime(d.year, d.month, d.day, 23, 59, 59).timestamp())
    return s, e

@flask_app.route("/api/status")
def api_status():
    return jsonify({"tracking": _running, "platform": SYSTEM, "db": str(DB_PATH)})

@flask_app.route("/api/today")
def api_today():
    start, end = _day_bounds()
    with get_db() as db:
        rows = db.execute(
            "SELECT app,title,domain,obsidian_note,obsidian_vault,source,ts,duration "
            "FROM events WHERE ts BETWEEN ? AND ? ORDER BY ts",
            (start, end)).fetchall()

    # Total = primary monitor only, so second monitor + music don't double-count.
    PRIMARY = {"focus", "mon0"}
    total = sum(r["duration"] for r in rows
                if (r["source"] or "focus") in PRIMARY)

    apps, domains, obs_notes, cats, music = {}, {}, {}, {}, {}
    # Secondary monitors tracked separately so they show in UI but don't inflate total
    secondary_apps = {}

    for r in rows:
        src = r["source"] or "focus"
        if src == "music":
            music[r["app"]] = music.get(r["app"], 0) + r["duration"]
            cats["Музыка"] = cats.get("Музыка", 0) + r["duration"]
            continue
        # Primary monitor: counts toward categories, apps, domains
        if src in PRIMARY:
            apps[r["app"]] = apps.get(r["app"], 0) + r["duration"]
            cat = category_for_event(r["app"], r["domain"])
            cats[cat] = cats.get(cat, 0) + r["duration"]
            if r["domain"]:
                domains[r["domain"]] = domains.get(r["domain"], 0) + r["duration"]
            if r["obsidian_note"]:
                key = r["obsidian_note"]
                if key not in obs_notes:
                    obs_notes[key] = {"note": key, "vault": r["obsidian_vault"], "seconds": 0}
                obs_notes[key]["seconds"] += r["duration"]
        else:
            # Secondary monitors: shown separately, don't affect categories/total
            secondary_apps[r["app"]] = secondary_apps.get(r["app"], 0) + r["duration"]

    # Build rule progress: each goal/limit gets its current seconds.
    # Supported target types: category, app, domain (site), obsidian (note).
    obs_seconds = {k: v["seconds"] for k, v in obs_notes.items()}
    rules_out = []
    for rule in load_settings().get("rules", []):
        tgt  = rule.get("target")
        typ  = rule.get("type", "category")
        if typ == "category":
            seconds = cats.get(tgt, 0)
        elif typ == "app":
            seconds = apps.get(tgt, 0)
        elif typ == "domain":
            seconds = domains.get(tgt, 0)
        elif typ == "obsidian":
            seconds = obs_seconds.get(tgt, 0)
        else:
            seconds = 0
        target_sec = rule.get("seconds", 0)
        kind = rule.get("kind", "goal")
        pct = round((seconds / target_sec) * 100) if target_sec > 0 else 0
        rules_out.append({
            "target":   tgt,
            "type":     typ,
            "kind":     kind,
            "seconds":  seconds,
            "target_seconds": target_sec,
            "pct":      pct,
            "done":     seconds >= target_sec if kind == "goal" else False,
            "exceeded": seconds > target_sec  if kind == "limit" else False,
        })

    # Timeline from primary monitor so the bars reflect real on-screen time.
    slots = {}
    for r in rows:
        if (r["source"] or "focus") not in ("focus", "mon0"):
            continue
        slot = (r["ts"] - start) // 1800
        if slot not in slots:
            slots[slot] = {"slot": slot, "apps": {}, "total": 0}
        slots[slot]["apps"][r["app"]] = slots[slot]["apps"].get(r["app"], 0) + r["duration"]
        slots[slot]["total"] += r["duration"]

    timeline = []
    for i in range(48):
        s = slots.get(i, {"slot": i, "apps": {}, "total": 0})
        s["label"] = f"{(i*30)//60:02d}:{(i*30)%60:02d}"
        timeline.append(s)

    return jsonify({
        "total_seconds": total,
        "top_apps":     [{"name":k,"seconds":v}   for k,v in sorted(apps.items(),    key=lambda x:x[1], reverse=True)[:10]],
        "top_domains":  [{"domain":k,"seconds":v} for k,v in sorted(domains.items(), key=lambda x:x[1], reverse=True)[:10]],
        "top_obsidian": sorted(obs_notes.values(), key=lambda x: x["seconds"], reverse=True),
        "top_music":    [{"name":k,"seconds":v}   for k,v in sorted(music.items(),   key=lambda x:x[1], reverse=True)[:10]],
        "music_total":  sum(music.values()),
        "secondary_apps": [{"name":k,"seconds":v} for k,v in sorted(secondary_apps.items(), key=lambda x:x[1], reverse=True)[:5]],
        "categories":   [{"name":k,"seconds":v}   for k,v in sorted(cats.items(),    key=lambda x:x[1], reverse=True)],
        "rules":        rules_out,
        "timeline":     timeline,
        "event_count":  len(rows),
        "idle":         _is_idle,
        "watching":     _is_watching,
        "music":        _is_music,
        "music_now":    _music_label,
    })

@flask_app.route("/api/current")
def api_current():
    with _lock:
        return jsonify({"app": _last_app or "—", "title": _last_title or "—", "tracking": _running})

@flask_app.route("/api/toggle", methods=["POST"])
def api_toggle():
    if _running: stop_tracker()
    else:        start_tracker()
    return jsonify({"tracking": _running})

@flask_app.route("/api/export", methods=["POST"])
def api_export():
    vault = request.json.get("vault_path") if request.json else None
    result = export_today_to_obsidian(Path(vault) if vault else None)
    ok = not result.startswith("error")
    return jsonify({"ok": ok, "path": result})

@flask_app.route("/api/vault_status")
def api_vault_status():
    vp = _obsidian_vault_path or _find_obsidian_vault()
    return jsonify({
        "vault": str(vp) if vp else None,
        "found": vp is not None
    })

@flask_app.route("/api/settings", methods=["GET"])
def api_get_settings():
    s = load_settings()
    return jsonify({
        "idle_enabled":         s.get("idle_enabled", True),
        "idle_threshold":       s.get("idle_threshold", DEFAULT_IDLE_THRESHOLD),
        "watch_enabled":        s.get("watch_enabled", True),
        "music_enabled":        s.get("music_enabled", True),
        "multimonitor_enabled": s.get("multimonitor_enabled", True),
        "break_enabled":        s.get("break_enabled", True),
        "break_minutes":        s.get("break_minutes", 50),
        "limit_notify_enabled": s.get("limit_notify_enabled", True),
        "categories":           s.get("categories", {}),
        "domain_categories":    s.get("domain_categories", {}),
        "rules":                s.get("rules", []),
    })

@flask_app.route("/api/settings", methods=["POST"])
def api_save_settings():
    data = request.json or {}
    allowed = {}
    if "idle_enabled" in data:
        allowed["idle_enabled"] = bool(data["idle_enabled"])
    if "watch_enabled" in data:
        allowed["watch_enabled"] = bool(data["watch_enabled"])
    if "music_enabled" in data:
        allowed["music_enabled"] = bool(data["music_enabled"])
    if "multimonitor_enabled" in data:
        allowed["multimonitor_enabled"] = bool(data["multimonitor_enabled"])
    if "break_enabled" in data:
        allowed["break_enabled"] = bool(data["break_enabled"])
    if "break_minutes" in data:
        try:
            allowed["break_minutes"] = max(5, min(180, int(data["break_minutes"])))
        except (ValueError, TypeError):
            pass
    if "limit_notify_enabled" in data:
        allowed["limit_notify_enabled"] = bool(data["limit_notify_enabled"])
    if "idle_threshold" in data:
        try:
            allowed["idle_threshold"] = max(30, int(data["idle_threshold"]))
        except (ValueError, TypeError):
            pass
    if "categories" in data and isinstance(data["categories"], dict):
        allowed["categories"] = data["categories"]
    if "domain_categories" in data and isinstance(data["domain_categories"], dict):
        allowed["domain_categories"] = data["domain_categories"]
    if "rules" in data and isinstance(data["rules"], list):
        valid_types = {"category", "app", "domain", "obsidian"}
        clean = []
        for r in data["rules"]:
            try:
                rtype = r.get("type")
                if rtype not in valid_types:
                    rtype = "category"
                clean.append({
                    "target":  str(r["target"]),
                    "type":    rtype,
                    "kind":    "limit" if r.get("kind") == "limit" else "goal",
                    "seconds": max(0, int(r["seconds"])),
                })
            except (KeyError, ValueError, TypeError):
                continue
        allowed["rules"] = clean
    saved = save_settings(allowed)
    return jsonify({"ok": True, "settings": saved})

@flask_app.route("/api/test_notification", methods=["POST"])
def api_test_notification():
    """Fire a test toast so the user can confirm notifications work."""
    _send_notification("DayTrace", "Уведомления работают. Так будут приходить напоминания.")
    return jsonify({"ok": True})

@flask_app.route("/api/known_apps")
def api_known_apps():
    """Apps and domains seen in the last 30 days, plus built-in lists,
    so the settings UI can offer useful dropdowns."""
    cutoff = int(time.time()) - 30 * 86400
    seen = set()
    doms = set()
    notes = set()
    try:
        with get_db() as db:
            for r in db.execute(
                "SELECT DISTINCT app FROM events WHERE ts > ?", (cutoff,)):
                seen.add(r["app"])
            for r in db.execute(
                "SELECT DISTINCT domain FROM events WHERE ts > ? AND domain IS NOT NULL", (cutoff,)):
                if r["domain"]:
                    doms.add(r["domain"])
            for r in db.execute(
                "SELECT DISTINCT obsidian_note FROM events WHERE ts > ? AND obsidian_note IS NOT NULL", (cutoff,)):
                if r["obsidian_note"]:
                    notes.add(r["obsidian_note"])
    except Exception:
        pass
    seen.update(APP_NAMES.values())
    doms.update(DEFAULT_DOMAIN_CATEGORIES.keys())
    doms.update(load_settings().get("domain_categories", {}).keys())
    # Merge notes from DB (recently seen) with notes scanned from vault (all notes).
    notes.update(_scan_vault_notes())
    cats = sorted(set(load_settings().get("categories", {}).values()) |
                  set(load_settings().get("domain_categories", {}).values()) |
                  {DEFAULT_CATEGORY, "Работа", "Учёба", "Общение", "Браузер", "Развлечения", "Музыка"})
    return jsonify({"apps": sorted(seen), "domains": sorted(doms),
                    "notes": sorted(notes), "categories": cats})

@flask_app.route("/")
def index():
    return send_from_directory(flask_app.static_folder, "index.html")

def run_flask():
    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    flask_app.run(host="127.0.0.1", port=PORT, debug=False, use_reloader=False)

# ── Tray icon ─────────────────────────────────────────────────────────────────
def _make_icon_image():
    from PIL import Image, ImageDraw
    size = 64
    img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.ellipse([2, 2, 61, 61], fill="#3b82f6")
    draw.rectangle([16, 16, 22, 48], fill="white")
    draw.ellipse([16, 16, 48, 48], fill="#3b82f6")
    draw.ellipse([22, 22, 42, 42], fill="white")
    draw.rectangle([16, 16, 30, 48], fill="white")
    draw.rectangle([34, 16, 50, 21], fill="white")
    draw.rectangle([40, 16, 45, 48], fill="white")
    return img

def open_dashboard(_icon=None, _item=None):
    webbrowser.open(f"http://localhost:{PORT}")

def toggle_tracking_tray(icon, item):
    if _running: stop_tracker()
    else:        start_tracker()
    icon.menu = _build_menu(icon)
    icon.update_menu()

def _build_menu(icon=None):
    import pystray
    status       = "Tracking: ON"   if _running else "Tracking: OFF"
    toggle_label = "Pause tracking" if _running else "Resume tracking"
    return pystray.Menu(
        pystray.MenuItem("DayTrace",       None, enabled=False),
        pystray.MenuItem(status,           None, enabled=False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Open dashboard", open_dashboard, default=True),
        pystray.MenuItem(toggle_label,     toggle_tracking_tray),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Quit",           lambda icon, item: icon.stop()),
    )

def run_tray():
    import pystray
    icon = pystray.Icon("DayTrace", _make_icon_image(), "DayTrace", menu=_build_menu())
    icon.run()

# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    start_tracker()
    threading.Thread(target=run_flask,        daemon=True).start()
    threading.Thread(target=_auto_export_loop, daemon=True).start()
    time.sleep(1.2)
    webbrowser.open(f"http://localhost:{PORT}")
    try:
        run_tray()
    except Exception as e:
        print(f"Tray not available ({e}), running headless.")
        print(f"Open http://localhost:{PORT} in your browser.")
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            pass
